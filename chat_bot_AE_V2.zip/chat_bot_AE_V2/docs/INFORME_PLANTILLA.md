# Guía del PDF de entrega (Avance 2)

Exporta este contenido a PDF (Word/Docs → PDF) con las imágenes pegadas. Sigue el orden de la rúbrica.

## 1. Portada
Título, integrantes, curso, fecha, **URL pública** y **enlace al repositorio**.

## 2. Diagrama del flujo RAG y parámetros
- Imagen: `docs/diagrama_flujo_rag.png`.
- Tabla de decisiones: copia la sección 2 del README (corpus, chunking 500/50, embeddings MiniLM multilingüe, ChromaDB coseno, top_k=10, umbral 0.20, Groq gpt-oss-120b T=0).
- Justificación del corpus (pertinencia al dominio): README §1.

## 3. Capturas de consultas sobre el RAG + análisis
Pega 4–5 capturas (consola `python -m scripts.chat_cli` con `verbose`, o la web) y, para cada una, 2–3 líneas:

| Consulta | Qué se recuperó (doc/pág.) | ¿La respuesta es correcta y está citada? | Observación |
|---|---|---|---|
| ¿Cuál es el máximo de ausencias…? | | | |
| ¿Cuáles son las dimensiones del alcance en TOGAF? | | | |
| ¿Cómo se distribuyen las notas en Pre-Cálculo? | | | |
| Una pregunta fuera del corpus | | | |

## 4. Resultados Ragas
1. Tabla de la línea base (`eval/resultados/base_resumen.json`): 4 métricas Ragas + hit-rate + abstenciones.
2. Gráfico: `eval/resultados/comparacion.png`.
3. **Análisis** (responde las tres preguntas de la rúbrica):
   - ¿Qué métrica salió más baja?
   - ¿A qué componente se atribuye (chunking, recuperación o generación)? Apóyate en el hit-rate y en las filas con peor puntaje de `*_ragas_detalle.csv`.
   - ¿Qué se haría para mejorarla?
4. **Iteración de mejora**: parámetro modificado, motivo, tabla antes/después (`comparacion.md`) e interpretación (¿mejoró? ¿empeoró otra métrica?).
5. Control de alucinaciones: tasa de abstención correcta en las 5 preguntas fuera del corpus (y cuáles fallaron).

## 5. Interfaz desplegada
Capturas de la URL pública:
1. Pantalla inicial.
2. Conversación con **pregunta de seguimiento** (ej.: «¿Cuál es el máximo de ausencias?» → «¿Y qué pasa si lo supero?»), con el desplegable de **Fuentes** abierto.
3. Caso **fuera del corpus** (mensaje ámbar «No encontré información…»).

## 6. Enlaces finales
URL pública · URL del repositorio GitHub.
