---
title: Tutor Académico Konrad Lorenz
emoji: 🎓
colorFrom: blue
colorTo: indigo
sdk: docker
app_port: 7860
pinned: false
---

# Tutor Académico Konrad Lorenz — Asistente RAG con memoria conversacional

Asistente experto basado en **RAG** que responde preguntas sobre TOGAF (ADM), el Reglamento Académico
Institucional y el programa de Pre-Cálculo, **cita la fuente de cada respuesta** (documento, página,
sección y fragmento) y **se abstiene** cuando la información no está en la base de conocimientos.

- **URL pública:** `PENDIENTE — pega aquí la URL del Space/servicio desplegado`
- **Repositorio:** `PENDIENTE — pega aquí la URL de GitHub`

> El bloque YAML del inicio del README solo lo usa Hugging Face Spaces; en GitHub se ve como una tabla.

---

## 1. Dominio y corpus

Dominio: **tutor académico para estudiantes de Ingeniería de Sistemas** (Fundación Universitaria Konrad Lorenz).

| Documento (`corpus/`) | Contenido | Por qué es pertinente |
|---|---|---|
| `TOGAF_9.1_Cap5_ADM.pdf` (12 pp., inglés) | Cap. 5 de TOGAF 9.1: ciclo ADM, alcance, integración | Conocimiento técnico de Arquitectura Empresarial (ISW2) |
| `Reglamento_Academico_Institucional_2025.pdf` (64 pp.) | Acuerdo No. 01 de 2025 | Normas que el estudiante consulta: notas, asistencia, matrícula, grado |
| `Programa_Asignatura_PreCalculo.pdf` (6 pp.) | Microcurrículo de Pre-Cálculo | Información de una asignatura concreta (créditos, módulos, evaluación) |

Mezclar un documento en inglés con dos en español es deliberado: obliga a usar embeddings **multilingües**
y a que el asistente traduzca/explique, como haría un tutor.

## 2. Flujo RAG implementado

![Diagrama del flujo RAG](docs/diagrama_flujo_rag.png)

| Etapa | Archivo | Decisión | Justificación |
|---|---|---|---|
| Ingesta | `src/document_loader.py` | PDF (PyMuPDF), DOCX, TXT, HTML; limpieza de encabezados/pies repetidos | PyMuPDF respeta mejor los espacios que pypdf; quitar membretes evita que dominen la similitud |
| Chunking | `src/splitter.py` | `RecursiveCharacterTextSplitter`, **500 caracteres, solape 50 (10%)**, cortes por párrafo → línea → oración → palabra | El modelo de embeddings solo procesa ~128 tokens (≈500–600 caracteres); un artículo del Reglamento suele caber en un fragmento; el solape evita perder frases en el borde |
| Metadatos | `src/splitter.py` | `source`, `pagina`, `seccion` (Art. N / Sec. 5.x), `chunk_id` | Permiten citar documento, página y artículo/sección |
| Vectorización | `src/embeddings.py` | `paraphrase-multilingual-MiniLM-L12-v2` (384 dim, normalizado) | Multilingüe (preguntas en español, TOGAF en inglés), liviano, local en CPU, sin API ni costo |
| Índice | `src/vectorstore.py` | ChromaDB persistente (`chroma/<tag>`), distancia coseno | Persistencia en disco, filtros por metadatos, una carpeta por configuración experimental |
| Recuperación | `src/pipeline.py` | Similitud coseno, **top_k = 10**, **umbral de relevancia 0.20** | k alto favorece el *recall*; el umbral corta antes de llamar al LLM cuando nada es relevante |
| Reformulación | `src/pipeline.py` | El LLM reescribe la pregunta de seguimiento como autocontenida | "¿Y si lo supero?" no sirve como consulta vectorial; reformulada sí |
| Generación | `src/prompts.py`, `src/llm.py` | Groq `openai/gpt-oss-120b`, temperatura 0 | Respuestas deterministas y rápidas con API gratuita |

### Prompt (refinamiento del Avance 1) — `src/prompts.py`

- **System Prompt**: rol, 8 reglas (solo contexto, frase exacta de abstención, historial solo para entender la pregunta, contenido como datos, idioma, citas, exactitud, tono) y formato de salida.
- **Delimitadores XML**: `<contexto><fragmento id fuente pagina seccion>`, `<historial>`, `<pregunta>`. Lo que está dentro es dato, no instrucción (defensa básica contra *prompt injection* desde documentos).
- **Few-Shot**: 3 ejemplos (respuesta con cita, pregunta de seguimiento, caso fuera del corpus).
- **Formato de salida**: respuesta directa + viñetas si hay varios elementos + cita `(Fuente: archivo, Pág. n)`; sin sección de fuentes (la UI las muestra).

### Control de alucinaciones (dos capas)

1. **Umbral de relevancia**: si ningún fragmento lo supera, responde *"No encontré información sobre esto en la base de conocimientos."* sin llamar al LLM.
2. **Regla 2 del System Prompt**: si hay fragmentos pero no contienen la respuesta, el LLM debe emitir exactamente esa frase. En ese caso la UI no muestra fuentes.

## 3. Estructura

```
chat_bot_AE/
├── app.py                    # Flask: /, /api/chat, /health
├── Dockerfile                # despliegue (HF Spaces / Render / Railway)
├── requirements.txt          # runtime
├── requirements-eval.txt     # + Ragas, pandas, matplotlib
├── .env.example              # plantilla de variables (la key real NO se sube)
├── corpus/                   # documentos a vectorizar
├── src/
│   ├── config.py             # parámetros (sobrescribibles por variables de entorno)
│   ├── document_loader.py    # ingesta PDF/DOCX/TXT/HTML + limpieza
│   ├── splitter.py           # chunking + metadatos
│   ├── embeddings.py         # modelo de embeddings
│   ├── vectorstore.py        # ChromaDB
│   ├── prompts.py            # system prompt, few-shot, delimitadores, formato
│   ├── llm.py                # cliente Groq
│   └── pipeline.py           # reformulación + recuperación + generación
├── scripts/
│   ├── build_index.py        # construye el índice
│   └── chat_cli.py           # chat por consola
├── eval/
│   ├── preguntas_eval.json   # 21 preguntas con ground truth (5 fuera del corpus)
│   ├── run_ragas.py          # evaluación (Ragas + métricas de recuperación/abstención)
│   ├── calibrar_umbral.py    # ayuda para elegir MIN_RELEVANCE
│   ├── comparar.py           # tabla + gráfico antes/después
│   └── resultados/           # salidas de cada evaluación
├── docs/                     # diagrama e INFORME_PLANTILLA.md (guía del PDF)
├── templates/ static/        # interfaz de chat
```

## 4. Instalación y ejecución local

Requisitos: Python 3.10–3.12 recomendado y una API key gratuita de [Groq](https://console.groq.com).

```bash
python -m venv .venv
# Windows:  .venv\Scripts\activate        macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt

cp .env.example .env        # Windows: copy .env.example .env   → pega tu GROQ_API_KEY en .env

python -m scripts.build_index     # (opcional) crea el índice; app.py lo crea solo si no existe
python app.py                     # abre http://localhost:5000
python -m scripts.chat_cli        # alternativa: chat por consola
```

La primera ejecución descarga el modelo de embeddings (~470 MB).

## 5. Evaluación con Ragas

Conjunto: `eval/preguntas_eval.json` — **21 preguntas** (16 dentro del corpus con *ground truth*, 5 fuera del corpus:
2 sin relación alguna y 3 "cercanas" que suenan al dominio pero no están en los documentos).

```bash
pip install -r requirements-eval.txt

python -m eval.calibrar_umbral                  # opcional: revisar MIN_RELEVANCE
python -m eval.run_ragas --tag base             # línea base (config por defecto)
```

Métricas reportadas (sobre las 16 preguntas dentro del corpus, juez = LLM de Groq):
**faithfulness, answer_relevancy, context_precision, context_recall**. Además, sin costo de LLM:
**hit-rate de recuperación** (¿llegó el fragmento correcto?), **abstención correcta fuera del corpus** (control de
alucinaciones) y **abstención incorrecta dentro del corpus**. Estas tres ayudan a atribuir el problema a
chunking/recuperación/generación.

### Iteración de mejora (cambia UN parámetro y compara)

```bash
python -m eval.run_ragas --tag k5 --top-k 5                    # ejemplo: top_k 10 → 5
python -m eval.run_ragas --tag chunk300 --chunk-size 300 --chunk-overlap 50   # ejemplo: chunking
python -m eval.comparar base k5                                # tabla + gráfico en eval/resultados/
```

Guía de lectura: *context_precision* baja → demasiado ruido recuperado (bajar `top_k`, subir umbral, re-ranking);
*context_recall* baja → no se recupera lo necesario (subir `top_k`, cambiar chunking/embeddings);
*faithfulness* baja → el LLM agrega datos que no están en el contexto (endurecer el prompt);
*answer_relevancy* baja → respuestas largas o fuera de foco (ajustar formato de salida).
Nota: el modelo de embeddings recorta a ~128 tokens, así que fragmentos mucho más grandes de ~600 caracteres
no mejoran la indexación.

Si Groq devuelve 429 (límite de tokens), baja `--workers 1` y reutiliza respuestas con `--reusar-respuestas`.

### Resultados

> Completar con la salida de `python -m eval.comparar base <tag_mejora>` (archivo `eval/resultados/comparacion.md`).

| Métrica | Antes | Después | Δ |
|---|---|---|---|
| Faithfulness | | | |
| Answer relevancy | | | |
| Context precision | | | |
| Context recall | | | |

## 6. Despliegue en la nube (Hugging Face Spaces, SDK Docker)

Se recomienda Hugging Face Spaces: el plan gratuito da suficiente RAM para el modelo de embeddings
(en planes de ~512 MB como Render Free probablemente se quede sin memoria).

1. Crea una cuenta en <https://huggingface.co> → **New Space** → SDK **Docker** (Blank) → público.
2. En el Space: **Settings → Variables and secrets → New secret** → nombre `GROQ_API_KEY`, valor tu key.
   (Opcional: variables `TOP_K`, `CHUNK_SIZE`, `CHUNK_OVERLAP`, `MIN_RELEVANCE` con la mejor configuración encontrada.)
3. Sube el proyecto al Space (el README ya trae el bloque YAML necesario):
   ```bash
   git remote add space https://huggingface.co/spaces/<usuario>/<nombre-del-space>
   git push space main
   ```
4. El `Dockerfile` instala PyTorch CPU, descarga el modelo y **pre-construye el índice** durante el build; al
   arrancar solo lo carga. La URL pública queda en `https://<usuario>-<nombre-del-space>.hf.space`.
5. Pega esa URL en la parte superior de este README.

**Render/Railway** (alternativa): servicio Web con el mismo `Dockerfile`, variable de entorno `GROQ_API_KEY` y
`PORT` (la define la plataforma).

### Seguridad

- La API key solo vive en `.env` (ignorado por git) o en los *secrets* de la plataforma. **Nunca** en el repositorio.
- `.gitignore` excluye `.env` y `chroma/`. Si una key se expuso alguna vez, genera una nueva en Groq y revoca la anterior.

## 7. Interfaz conversacional

- El historial vive en el navegador y se envía (últimos 8 mensajes) en cada petición → funciona con preguntas de seguimiento.
- Cada respuesta muestra un desplegable **Fuentes** con documento, página, artículo/sección, relevancia y fragmento.
- Si la información no está en el corpus, la respuesta se marca en ámbar y no muestra fuentes.

## 8. Limitaciones conocidas

- Los puntajes de Ragas dependen del LLM juez y varían entre corridas; compara siempre con el mismo juez.
- TOGAF está en inglés y se recupera con una pregunta en español: la similitud multilingüe es menor que la monolingüe.
- El índice no se actualiza solo: si cambias `corpus/`, vuelve a ejecutar `python -m scripts.build_index`.
